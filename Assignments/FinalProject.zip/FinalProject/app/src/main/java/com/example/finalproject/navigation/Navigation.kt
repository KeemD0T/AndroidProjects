package com.example.finalproject.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.finalproject.screens.HomeScreen
import com.example.finalproject.screens.TransactionScreen

// 1. DEFINE your navigation routes here as a sealed class.
// This is the clean, type-safe way to handle navigation.
sealed class Screen(val route: String) {
    object HomeScreen : Screen("home_screen")
    object TransactionScreen : Screen("transactions_screen")
    // Add other screens here as your app grows
}

/**
 * Defines the navigation graph for the application.
 */
@Composable
fun AppNavigation(
    navController: NavHostController,
    modifier: Modifier = Modifier
) {
    // NavHost is the container for all of your app's destinations
    NavHost(
        navController = navController,
        // 2. USE your new Screen object for the start destination.
        startDestination = Screen.HomeScreen.route,
        modifier = modifier
    ) {
        // Define the "Home" screen destination
        composable(route = Screen.HomeScreen.route) {
            HomeScreen(navController = navController)
        }

        // Define the "Transactions" screen destination
        composable(route = Screen.TransactionScreen.route) {
            TransactionScreen()
        }
    }
}
