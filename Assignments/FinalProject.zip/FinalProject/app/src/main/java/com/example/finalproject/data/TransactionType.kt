package com.example.finalproject.data

enum class TransactionType {
    EXPENSE,
    INCOME
}

