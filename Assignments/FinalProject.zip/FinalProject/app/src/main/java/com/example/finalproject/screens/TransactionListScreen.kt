package com.example.finalproject.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.finalproject.data.FinanceDatabase
import com.example.finalproject.data.Transaction
import com.example.finalproject.data.TransactionType
//import androidx.wear.compose.foundation.weight
import com.example.finalproject.viewmodel.FinanceViewModel
import com.example.finalproject.viewmodel.FinanceViewModelFactory
import com.example.finalproject.data.FinanceRepository


@OptIn(ExperimentalMaterial3Api::class) // Required for TopAppBar
@Composable
fun TransactionScreen(financeViewModel: FinanceViewModel? = null) {
    val context = LocalContext.current
    val database = remember { FinanceDatabase.getDatabase(context.applicationContext) }
    val repository = remember { FinanceRepository(database.transactionDao(), database.categoryDao()) }
    val actualViewModel: FinanceViewModel = financeViewModel
        ?: viewModel(factory = FinanceViewModelFactory(repository))

    val transactions by actualViewModel.transactions.collectAsState()
    val categories by actualViewModel.categories.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Transactions", fontSize = 24.sp) }, // Changed title for this screen
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF8FABE7),
                    titleContentColor = Color(0xFF000000)
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding), // Use the padding provided by Scaffold
            verticalArrangement = Arrangement.spacedBy(8.dp),

        ) {
            // Check if the list is empty
            if (transactions.isEmpty()) {
                item {
                    Text(
                        text = "No transactions found. Add one to get started!",
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
            } else {
                // 2. FIX: Use 'items(transactions)' to iterate correctly
                items(transactions, key = { it.id }) { transaction ->
                    // 3. RENDER the new TransactionItem for each transaction
                    TransactionItem(
                        transaction = transaction,
                        onDeleteClick = {
                            // You need to implement this function in your ViewModel
                            // financeViewModel.deleteTransaction(transaction)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun TransactionItem(
    transaction: Transaction,
    onDeleteClick: () -> Unit
) {
    // Determine card color based on transaction type (Income/Expense)
    val cardColor by animateColorAsState(
        targetValue = if (transaction.type == TransactionType.INCOME) Color(0xFFE8F5E9) else Color(0xFFFBE9E7),
        animationSpec = tween(durationMillis = 300),
        label = "TransactionCardColor"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp), // Side margins for the card
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors = CardDefaults.cardColors(containerColor = cardColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 8.dp, top = 16.dp, bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left side: Transaction details
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "$${"%.2f".format(transaction.amount)}", // Format amount to 2 decimal places
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = transaction.type.name, // "Income" or "Expense"
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray
                )
                // You can add more details here, like date or description
            }
            // Right side: Delete button
            IconButton(onClick = onDeleteClick) {
                Icon(
                    imageVector = Icons.Filled.Delete,
                    contentDescription = "Delete Transaction",
                    tint = Color.Gray
                )
            }
        }
    }
}
