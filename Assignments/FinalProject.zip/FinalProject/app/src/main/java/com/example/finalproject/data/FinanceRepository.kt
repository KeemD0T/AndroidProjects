package com.example.finalproject.data
import kotlinx.coroutines.flow.Flow
import com.example.finalproject.data.Transaction
import com.example.finalproject.data.TransactionDao



class FinanceRepository(
    private val transactionDao: TransactionDao,
    private val CategoryDao: CategoryDao
){
    suspend fun insertTransaction(transaction: Transaction) {
        transactionDao.insertTransaction(transaction)
    }
    suspend fun getTransactionById(id: Long): Transaction? {
        return transactionDao.getTransactionById(id)
    }
    suspend fun getTotalByTypeAndDateRange(type: TransactionType, startDate: Long, endDate: Long): Double {
        return transactionDao.getTotalByTypeAndDateRange(type, startDate, endDate) ?: 0.0
    }

    suspend fun updateTransaction(transaction: Transaction) {
        transactionDao.updateTransaction(transaction)
    }
    suspend fun deleteTransaction(transaction: Transaction) {
        transactionDao.deleteTransaction(transaction)
    }

    val allTransactions: Flow<List<Transaction>> = transactionDao.getAllTransactions()
    val allCategories: Flow<List<Category>> = CategoryDao.getAllCategories()

}





