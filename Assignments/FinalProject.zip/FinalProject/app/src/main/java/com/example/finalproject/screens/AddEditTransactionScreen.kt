package com.example.finalproject.screens

import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp


@OptIn(ExperimentalMaterial3Api::class) // Required for TopAppBar
@Composable
fun AddEditTransactionScreen() { // The function that defines the screen's UI
    // 3. Place the Scaffold inside the composable function
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Edit Transaction", fontSize = 24.sp) }, // Changed title for this screen
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF8FABE7),
                    titleContentColor = Color(0xFF000000)
                )
            )
        }
    ) { innerPadding ->
        // 4. Add the required content block for the Scaffold.
        // The content for your "Add/Edit" screen will go here.
        // You must use the 'innerPadding' variable to avoid UI elements
        // being hidden by the top bar.
        //
        // Example:
        // Column(modifier = Modifier.padding(innerPadding)) {
        //     Text("Transaction details go here...")
        // }
    }
}