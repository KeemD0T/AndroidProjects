package com.example.finalproject.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import com.example.finalproject.data.FinanceRepository // This line is required
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import androidx.lifecycle.viewModelScope
import com.example.finalproject.data.Transaction
import com.example.finalproject.data.Category // <-- ADD THIS LINE

// Corrected: 'financeRepository' is now a private property of the class
class FinanceViewModel(private val financeRepository: FinanceRepository) : ViewModel() {


    // This is the private, mutable state that only the ViewModel can change.
    // It is initialized with a starting value, for example, 0.0.
    private val _currentBalance = MutableStateFlow(0.0)
    private val _Income = MutableStateFlow(0.0)
    private val _Expense = MutableStateFlow(0.0)

    // This is the public, read-only state that the UI will observe.
    // It is exposed as a StateFlow to prevent the UI from directly changing it.
    val currentbalance: StateFlow<Double> = _currentBalance.asStateFlow()
    val Income: StateFlow<Double> = _Income.asStateFlow()
    val Expense: StateFlow<Double> = _Expense.asStateFlow()

    val transactions: StateFlow<List<Transaction>> = financeRepository.allTransactions
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000), // Keeps the flow active for 5s after the last UI collector is gone
            initialValue = emptyList() // Start with an empty list
        )

    val categories: StateFlow<List<Category>> = financeRepository.allCategories
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    init {
        // In a real app, you would load these values from a database or API.
        // For this example, we are setting hardcoded initial values.
        val initialIncome = 1500.0
        val initialExpense = 450.0

        _Income.value = initialIncome
        _Expense.value = initialExpense
        // The current balance should be calculated from income and expense
        _currentBalance.value = initialIncome - initialExpense
    }


    private fun loadInitialBalance() {
        // In a real app, this would be an async call to your data source.
        // For this example, we'll just set a sample value.
        _currentBalance.value = -100.0
    }
    private fun loadInitialIncome() {
        _Income.value = 100.0
    }
    private fun loadInitialExpense() {
        _Expense.value = 50.0


    }


    // A function the UI can call to add an expense, which updates the balance.
    fun addExpense(amount: Double) {
        // Use .update for safe, atomic updates to the state.
        _Expense.update { currentExpense -> currentExpense + amount }
        _currentBalance.update { current -> current - amount }
    }

    // A function the UI can call to add income, which updates the balance.
    fun addIncome(amount: Double) {
        _Income.update { currentIncome -> currentIncome + amount }
        _currentBalance.update { current -> current + amount }
    }


    }
class FinanceViewModelFactory(
    private val repository: FinanceRepository
) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(FinanceViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return FinanceViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}