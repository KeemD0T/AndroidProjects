package com.example.finalproject.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.finalproject.data.FinanceDatabase
import com.example.finalproject.data.FinanceRepository
import com.example.finalproject.viewmodel.FinanceViewModel
import com.example.finalproject.viewmodel.FinanceViewModelFactory




@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    navController: NavController,
    financeViewModel: FinanceViewModel? = null) { // Use convention: lowercase parameter name

    val context = LocalContext.current
    val database = remember { FinanceDatabase.getDatabase(context.applicationContext) }
    val repository = remember { FinanceRepository(database.transactionDao(), database.categoryDao()) }
    val actualViewModel: FinanceViewModel = financeViewModel
        ?: viewModel(factory = FinanceViewModelFactory(repository))

    val currentbalance by actualViewModel.currentbalance.collectAsState()
    val income by actualViewModel.Income.collectAsState()
    val expense by actualViewModel.Income.collectAsState()


    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Finance Tracker", fontSize = 24.sp) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF8FABE7),
                    titleContentColor = Color(0xFF000000)
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 24.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF475D91)),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                // This single Column will layout all the card's content
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    // This centers the Icon and Text horizontally
                    horizontalAlignment = Alignment.Start
                ) {
                    // 1. Display Icon based on balance
                    if (currentbalance >= 0) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Positive Balance",
                            tint = Color(0xFF4CAF50), // Green color
                            modifier = Modifier.size(48.dp)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Negative Balance",
                            tint = Color(0xFFF44336), // Red color
                            modifier = Modifier.size(48.dp)
                        )
                    }

                    // Add a small space between the icon and the text
                    Spacer(modifier = Modifier.height(8.dp))

                    // 2. "Current Balance" label text (made smaller)
                    Text(
                        text = "Current Balance",
                        fontWeight = FontWeight.Normal, // Less emphasis
                        fontSize = 18.sp, // <<< FONT SIZE REDUCED
                        color = Color(0xFFEEEEF3)
                    )

                    // 3. The actual balance amount
                    Text(
                        // Format the balance to 2 decimal places for currency
                        text = "$${String.format("%.2f", currentbalance)}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 32.sp, // Keep this large for emphasis
                        color = Color.White
                    )
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly // This spaces the cards out
            ) {
                // --- Income Card ---
                Card(
                    modifier = Modifier.weight(1f), // Each card takes up equal space
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)) // Light green background
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {

                            Text(text = "Income", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                        Text(
                            text = "$${String.format("%.2f", income)}",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 22.sp,
                            color = Color(0xFF011102),
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.size(16.dp)) // Space between the two cards

                // --- Expense Card ---
                Card(
                    modifier = Modifier.weight(1f), // Each card takes up equal space
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)) // Light red background
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {

                            Spacer(modifier = Modifier.size(8.dp))
                            Text(text = "Expense", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                        Text(
                            text = "$${String.format("%.2f", expense)}",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 22.sp,
                            color = Color(0xFF150000),
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        }
    }
}


 //A preview function helps you see your UI in the Android Studio editor
